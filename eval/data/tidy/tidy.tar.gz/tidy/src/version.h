/* version information

  (c) 2007-2009 (W3C) MIT, ERCIM, Keio University
  See tidy.h for the copyright notice.

  CVS Info :

    $Author: arnaud02 $ 
    $Date: 2009/03/25 21:37:11 $ 
    $Revision: 1.46 $ 

*/

static const char TY_(release_date)[] = "25 March 2009";
